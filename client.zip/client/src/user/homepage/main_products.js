import shoes4 from "../../images/main_products/shoes1.jpg";
import shoes1 from "../../images/main_products/shoes3.jpg";
import shoes3 from "../../images/main_products/shoes_1.png";
import cloth1 from "../../images/main_products/cloth_1.webp";
import cloth2 from "../../images/main_products/cloth_2.jpg";
import cloth3 from "../../images/main_products/cloth_3.jpg";
import main1 from "../../images/main_products/main.jpg";
export const MAIN_PRODUCTS0 = [
  {
    id: 0,
    productName: "habesha",      productImage: main1,    }
  ]

export const MAIN_PRODUCTS = [
    {
      id: 1,
      productName: "shoe",      productImage: shoes1,    },
  
    {
      id: 3,      productName: "shoe",      productImage: shoes3,
    },
    
    {
        id: 4,        productName: "shoe",        productImage: shoes4,
      }

  ];
  export const MAIN_PRODUCTS1 = [
    {
        id: 7, productName1: "cloth", productImage1: cloth1,
      },
      {
        id: 8, productName1: "cloth", productImage1: cloth2,
      },
      {
        id: 9, productName1: "cloth", productImage1: cloth3,
      }
      
  ];
